const http = require('http');
const fs = require('fs').promises;

const server = http.createServer(async(req, res) => {
    
    if (req.url === '/'){
        res.end('Home');
    }else if(req.url === '/api'){
        res.end(JSON.stringify({mensagem: 'API funcionado'}));
    }else{
        res.statusCode = 404;
        res.end("Rota não encontrada");
    }
});

server.listen(3000);